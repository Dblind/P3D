using System;

namespace P3D
{
    class Setting
    {
        int ScreenWidth = 120;
        int ScreenHeight = 40;
        float PlayerX = 1.0f;
        float PlayerY = 1.0;
        float FpayerA = 1.0f;
        int MapHeight = 16, MapWidth = 16;
        float FOV = 3.14159 / 3;
        float Depth = 30.0f;
        string[] ma5p = new string[]; 
        // map [0] = new "asdf";
        // map [0] = new string;

    }

}