﻿using System;

namespace P3D
{
    class Program
    {
        static void Main5(string[] args)
        {
            
        }
    }
}
